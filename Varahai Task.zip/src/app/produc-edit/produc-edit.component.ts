import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-produc-edit',
  templateUrl: './produc-edit.component.html',
  styleUrls: ['./produc-edit.component.css']
})
export class ProducEditComponent implements OnInit {
  EditForm:any;
  id:any;
  // EditForm: FormGroup | any;
  constructor(private Fbuil:FormBuilder,private api:ApiserviceService,private route:ActivatedRoute,private router:Router ) { }

  

  ngOnInit(): void {
    this.EditForm=this.Fbuil.group({
      title:new FormControl(" "),
      image:new FormControl(" "),
      price:new FormControl(" "),

    })

    this.id=this.route.snapshot.params.id;
    // This Bill get the id From Browser

    this.api.get(this.id).subscribe(
    product => this.EditForm.patchValue(product)
    )
  }

  // patch Value is used to Replace The Form Value

  Submit(){
    this.api.Update(this.id,this.EditForm.getRawValue()).subscribe(() =>{
      this.router.navigate(['/Products'])
    })


  }

}
