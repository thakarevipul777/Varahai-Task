import { Product } from './../interface/product';
import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  constructor(private api:ApiserviceService) { }

  ngOnInit(): void {
    this.api.getdata().subscribe(res =>{
      this.products=res;
    })
  }
  products:Product[]=[]

  Delete(id:number):void{

      this.api.delete(id).subscribe(() =>{
      this.products = this.products.filter(p=>p.id !==id);
    })
    
  }

}
