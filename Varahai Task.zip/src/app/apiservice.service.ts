import { HttpClient } from '@angular/common/http';
import { Product } from './interface/product';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ApiserviceService {

  constructor(private http:HttpClient) { }
  apiUrl=" http://localhost:3000/products";

  getdata():Observable<Product[]>{
   return this.http.get<Product[]>(this.apiUrl)
  }

  Create(data:any):Observable<Product[]>{
    return this.http.post<Product[]>(this.apiUrl,data)
   }
  // Because only the Single Data Will Be Passed So No Need To give the Arraay([]) 
   get(id:number):Observable<Product>{
    return this.http.get<Product>(`${this.apiUrl}/${id}`)
   }

   Update(id:any,data:any):Observable<Product>{
    return this.http.put<Product>(`${this.apiUrl}/${id}`,data)
   }

   delete(id:number):Observable<void>{
    return this.http.delete<void>(`${this.apiUrl}/${id}`)
   }
 

}
