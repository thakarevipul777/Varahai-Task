import { HttpClientModule } from '@angular/common/http';
import { ApiService } from './../../../Rio/src/app/api.service';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { NavComponent } from './nav/nav.component';
import { HomeComponent } from './home/home.component';
import { MotorCycleComponent } from './motor-cycle/motor-cycle.component';
import { CarsComponent } from './cars/cars.component';
import { MobileComponent } from './mobile/mobile.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { ActivateGuard } from './activate.guard';
import { AddProductComponent } from './add-product/add-product.component';
import { ProducEditComponent } from './produc-edit/produc-edit.component';
import { EditComponent } from './edit/edit.component';
import { AddingProductsComponent } from './adding-products/adding-products.component';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    NavComponent,
    HomeComponent,
    MotorCycleComponent,
    CarsComponent,
    MobileComponent,
    RegistrationFormComponent,
    AddProductComponent,
    ProducEditComponent,
    EditComponent,
    AddingProductsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule
    
  ],
  providers: [ApiService],
  bootstrap: [AppComponent]
})
export class AppModule { }
