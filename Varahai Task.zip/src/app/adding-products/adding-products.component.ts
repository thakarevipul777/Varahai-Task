import { Route, Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';

@Component({
  selector: 'app-adding-products',
  templateUrl: './adding-products.component.html',
  styleUrls: ['./adding-products.component.css']
})
export class AddingProductsComponent implements OnInit {
  title:any="";
  image:any="";
  price:any="";
  constructor(private api:ApiserviceService,private route:Router) { }

  ngOnInit(): void {
    // this.api.Create()
  }

  submit(){
    
    const data={
      title:this.title,
      image:this.image,
      price:this.price
    }

    this.api.Create(data).subscribe( () =>{

      this.route.navigate(["/Products"])

    })

  }

}
