import { Router } from '@angular/router';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  OlxUser:any;

  submit=false;


  constructor( private formbuilder:FormBuilder,private route:Router) { }
 
  ngOnInit(): void {
    this.OlxUser = this.formbuilder.group({
      FirstName:new FormControl('',[Validators.required]),
      Password:new FormControl('',[Validators.required]),
      Check:new FormControl('',[Validators.required])
    })  
  }

  get f(){
    return this.OlxUser.controls
  }
  Submit(){
    
    this.submit=true;
    if(this.OlxUser.invalid){
      return
    }
    
    if(this.f.FirstName.value=="Admin" && this.f.Password.value=="Admin"){
      this.route.navigate(['/Home']);
    }
    else{
     alert("Please Enter The valid User name And Password")
    }
  }

  
   FirstName(){
    return this.OlxUser.get('FirstName')
  }
  
  Password(){
    return this.OlxUser.get('Password')
  }
 Check(){
    return this.OlxUser.get('Check')
  }
  // this.route.navigate(['/inder']);

  Regiseter(){

    this.route.navigate(['/Register']);
  
  }
  
  

}
