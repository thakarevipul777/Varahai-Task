import { AddingProductsComponent } from './adding-products/adding-products.component';
import { EditComponent } from './edit/edit.component';
import { ProducEditComponent } from './produc-edit/produc-edit.component';
import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MotorCycleComponent } from './motor-cycle/motor-cycle.component';
import { CarsComponent } from './cars/cars.component';
import { MobileComponent } from './mobile/mobile.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { ActivateGuard } from './activate.guard';
import { AddProductComponent } from './add-product/add-product.component';

const routes: Routes = [
   {path:"",component:LoginComponent, },
   {path:"Home",component:HomeComponent},
   {path:"MotorCycle",component:MotorCycleComponent,canActivate: [ActivateGuard]},
   {path:"Cars",component:CarsComponent,canActivate: [ActivateGuard]},
   {path:"Mobile",component:MobileComponent,canActivate: [ActivateGuard]},
   {path:"Register",component:RegistrationFormComponent,canActivate: [ActivateGuard]},
   {path:"Products",component:AddProductComponent},
   {path:"AddProducts",component:AddingProductsComponent},
   {path:"Products/:id/Edit",component:ProducEditComponent},
  //  {path:"Products/:id/Edit",component:EditComponent},
   {path:"Login",component:LoginComponent},

   
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
