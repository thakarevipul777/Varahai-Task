import { LoginComponent } from './login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { MotorCycleComponent } from './motor-cycle/motor-cycle.component';
import { CarsComponent } from './cars/cars.component';
import { MobileComponent } from './mobile/mobile.component';
import { RegistrationFormComponent } from './registration-form/registration-form.component';
import { ActivateGuard } from './activate.guard';

const routes: Routes = [
   {path:"",component:LoginComponent, },
   {path:"Home",component:HomeComponent,canActivate: [ActivateGuard]},
   {path:"MotorCycle",component:MotorCycleComponent,canActivate: [ActivateGuard]},
   {path:"Cars",component:CarsComponent,canActivate: [ActivateGuard]},
   {path:"Mobile",component:MobileComponent,canActivate: [ActivateGuard]},
   {path:"Register",component:RegistrationFormComponent,canActivate: [ActivateGuard]},
   
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
