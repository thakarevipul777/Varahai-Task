import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration-form',
  templateUrl: './registration-form.component.html',
  styleUrls: ['./registration-form.component.css']
})
export class RegistrationFormComponent implements OnInit {


  
  OlxUser:any;

  submit=false;

  constructor(private formbuilder:FormBuilder,private route:Router) { }

  ngOnInit(): void {
    this.OlxUser = this.formbuilder.group({
      FirstName:new FormControl('',[Validators.required]),
      Password:new FormControl('',[Validators.required]),
      Mobile:new FormControl('',[Validators.required]),
      Email:new FormControl('',[Validators.required]),
      Address:new FormControl('',[Validators.required]),    
      Check:new FormControl('',[Validators.required]),
    })  
  }
  
  Submit(){
    
    this.submit=true;
    if(this.OlxUser.invalid){
      return
    }
    else{
      console.log(this.OlxUser.value)
    }

  }
  get f(){
    return this.OlxUser.controls
  }
   FirstName(){
    return this.OlxUser.get('FirstName')
  }
  
  Password(){
    return this.OlxUser.get('Password')
  }
  Mobile(){
    return this.OlxUser.get('Mobile')
  }
  
  Address(){
    return this.OlxUser.get('Address')
  }
  Email(){
    return this.OlxUser.get('Email')
  }

 Check(){
    return this.OlxUser.get('Check')
  }
  

}
