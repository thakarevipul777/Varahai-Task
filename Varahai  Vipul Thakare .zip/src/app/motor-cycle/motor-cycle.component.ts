import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-motor-cycle',
  templateUrl: './motor-cycle.component.html',
  styleUrls: ['./motor-cycle.component.css']
})
export class MotorCycleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
