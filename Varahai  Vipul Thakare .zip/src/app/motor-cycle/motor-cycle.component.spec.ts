import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MotorCycleComponent } from './motor-cycle.component';

describe('MotorCycleComponent', () => {
  let component: MotorCycleComponent;
  let fixture: ComponentFixture<MotorCycleComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MotorCycleComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MotorCycleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
